package edu.cs.dartmouth.myruns1.Preferences;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

public class UserData {

    private SharedPreferences userData;

    /* All the getters and setters to save and user info
     */
    public UserData(Context context) {
        userData = PreferenceManager.getDefaultSharedPreferences(context);
    }

    //These are all the setters

    public void setUserData(SharedPreferences userData) {
        this.userData = userData;
    }

    public void setUserPhoto(String imagePath) {
        userData.edit().putString("imagePath", imagePath).apply();
    }

    public void setUserName(String userName) {
        userData.edit().putString("username", userName).apply();
    }

    // makes gender correlated with boolean value as a tracker
    public void setUserGender(boolean userGender) {
        userData.edit().putBoolean("gender", userGender).apply();
    }

    public void setUserPassword(String userPassword) {
        userData.edit().putString("password", userPassword).apply();
    }

    public void setUserEmail(String userEmail) {
        userData.edit().putString("email", userEmail).apply();
    }

    public void setUserMajor(String userMajor) {
        userData.edit().putString("major", userMajor).apply();
    }

    public void setUserClass(String userClass) {
        userData.edit().putString("class", userClass).apply();
    }

    /* all of the getters
     */
    public String getUserPhoto() {
        return userData.getString("imagePath", "NA");
    }

    public String getUserName() {
        return userData.getString("username", "NA");
    }

    public boolean getUserGender() {
        return userData.getBoolean("gender", false);
    }

    public String getUserPassword() {
        return userData.getString("password", "NA");
    }

    public String getUserEmail() {
        return userData.getString("email", "NA");
    }

    public String getUserMajor() {
        return userData.getString("major", "NA");
    }

    public String getUserClass() {
        return userData.getString("class", "NA");
    }

    /* clears all data within the userData structure
     */
    public void clearAll() {
        userData.edit().remove("imagePath");
        userData.edit().remove("username");
        userData.edit().remove("gender");
        userData.edit().remove("password");
        userData.edit().remove("email");
        userData.edit().remove("major");
        userData.edit().remove("class");
    }

}
